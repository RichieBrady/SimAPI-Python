#!/bin/bash
 
python sim_api.py

