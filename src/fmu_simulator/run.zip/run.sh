#!/bin/bash

python ./simulator_api/sim_api.py \
& python simulation_process.py

