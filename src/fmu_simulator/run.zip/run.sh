#!/bin/bash

python sim_api.py \
& python sim_proc.py

