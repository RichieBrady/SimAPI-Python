#!/bin/bash

python sim_api.py \
& python new_proc.py

