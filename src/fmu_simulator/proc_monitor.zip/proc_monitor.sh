#!/bin/bash

until python sim_proc.py; do
    echo "'sim_proc.py' stopped with exit code $?. Restarting..." >&2
    sleep 1
done

